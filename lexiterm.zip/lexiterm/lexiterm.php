<?php
/**
 * Plugin Name:       LexiTerm
 * Plugin URI:        https://wordpress.org/plugins/lexiterm/
 * Description:       Generate SEO-friendly, human-like descriptions for categories and tags using OpenAI (ChatGPT) with a single click.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Umit OZAY
 * Author URI:        https://profiles.wordpress.org/umitozay/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       lexiterm
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ─────────────────────────────────────────────
 * Constants
 * ───────────────────────────────────────────── */
define( 'LEXITERM_VERSION', '1.0.0' );
define( 'LEXITERM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LEXITERM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'LEXITERM_BASENAME', plugin_basename( __FILE__ ) );



/* ─────────────────────────────────────────────
 * 2. SETTINGS PAGE
 * ───────────────────────────────────────────── */
add_action( 'admin_menu', 'lexiterm_add_settings_page' );
function lexiterm_add_settings_page() {
	add_options_page(
		__( 'LexiTerm Settings', 'lexiterm' ),
		__( 'AI Description', 'lexiterm' ),
		'manage_options',
		'lexiterm',
		'lexiterm_render_settings_page'
	);
}

/* Add settings link on plugin list page */
add_filter( 'plugin_action_links_' . LEXITERM_BASENAME, 'lexiterm_settings_link' );
function lexiterm_settings_link( $links ) {
	$settings_link = sprintf(
		'<a href="%s">%s</a>',
		admin_url( 'options-general.php?page=lexiterm' ),
		__( 'Settings', 'lexiterm' )
	);
	array_unshift( $links, $settings_link );
	return $links;
}

/* Register settings */
add_action( 'admin_init', 'lexiterm_register_settings' );
function lexiterm_register_settings() {
	register_setting( 'lexiterm_settings_group', 'lexiterm_api_key', array(
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '',
	) );
	register_setting( 'lexiterm_settings_group', 'lexiterm_model', array(
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => 'gpt-3.5-turbo',
	) );
	register_setting( 'lexiterm_settings_group', 'lexiterm_prompt', array(
		'type'              => 'string',
		'sanitize_callback' => 'wp_kses_post',
		'default'           => '',
	) );
}

/* Render settings page */
function lexiterm_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$default_prompt = __(
		"You are an experienced, SEO-expert content editor. Write a concise, natural, human-written description for the '{name}' category/tag on my website.\n\nRULES:\n1. Maximum 2-3 sentences.\n2. Do NOT use AI clichés (e.g., 'Welcome', 'Are you ready?'). Focus directly on action and content.\n3. Sentences should not repeat each other; avoid sounding mechanical.\n4. Naturally embed keywords like '{name}', 'free', 'online', 'best' into the text without forcing them.\n5. Use an energetic yet genuine tone that both informs and engages the visitor.",
		'lexiterm'
	);

	$api_key = get_option( 'lexiterm_api_key', '' );
	$model   = get_option( 'lexiterm_model', 'gpt-3.5-turbo' );
	$prompt  = get_option( 'lexiterm_prompt', $default_prompt );

	$models = array(
		'gpt-3.5-turbo' => 'GPT-3.5 Turbo',
		'gpt-4'         => 'GPT-4',
		'gpt-4o'        => 'GPT-4o',
		'gpt-4o-mini'   => 'GPT-4o Mini',
		'gpt-4-turbo'   => 'GPT-4 Turbo',
	);
	?>
	<div class="wrap aitd-settings-wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

		<form method="post" action="options.php">
			<?php settings_fields( 'lexiterm_settings_group' ); ?>

			<table class="form-table" role="presentation">
				<!-- API Key -->
				<tr>
					<th scope="row">
						<label for="lexiterm_api_key"><?php esc_html_e( 'OpenAI API Key', 'lexiterm' ); ?></label>
					</th>
					<td>
						<input
							type="password"
							id="lexiterm_api_key"
							name="lexiterm_api_key"
							value="<?php echo esc_attr( $api_key ); ?>"
							class="regular-text"
							placeholder="sk-..."
							autocomplete="off"
						/>
						<p class="description">
							<?php
							printf(
								/* translators: %s: OpenAI platform URL */
								esc_html__( 'Enter your OpenAI API key. You can obtain one from %s.', 'lexiterm' ),
								'<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">platform.openai.com</a>'
							);
							?>
						</p>
					</td>
				</tr>

				<!-- AI Model -->
				<tr>
					<th scope="row">
						<label for="lexiterm_model"><?php esc_html_e( 'AI Model', 'lexiterm' ); ?></label>
					</th>
					<td>
						<select id="lexiterm_model" name="lexiterm_model">
							<?php foreach ( $models as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $model, $value ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Select the OpenAI model to use for generating descriptions.', 'lexiterm' ); ?>
						</p>
					</td>
				</tr>

				<!-- Prompt -->
				<tr>
					<th scope="row">
						<label for="lexiterm_prompt"><?php esc_html_e( 'AI Prompt Template', 'lexiterm' ); ?></label>
					</th>
					<td>
						<textarea id="lexiterm_prompt" name="lexiterm_prompt" rows="10" class="large-text"><?php echo esc_textarea( $prompt ); ?></textarea>
						<p class="description">
							<?php
							printf(
								/* translators: %s: {name} variable */
								esc_html__( 'Customize the AI prompt. Use %s as a placeholder — it will be replaced with the category or tag name automatically.', 'lexiterm' ),
								'<code>{name}</code>'
							);
							?>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Settings', 'lexiterm' ) ); ?>
		</form>
	</div>
	<?php
}

/* ─────────────────────────────────────────────
 * 3. ADD COLUMNS TO CATEGORY & TAG TABLES
 * ───────────────────────────────────────────── */
add_filter( 'manage_edit-post_tag_columns', 'lexiterm_add_column' );
add_filter( 'manage_edit-category_columns', 'lexiterm_add_column' );
function lexiterm_add_column( $columns ) {
	$columns['lexiterm_action'] = __( 'AI Description', 'lexiterm' );
	return $columns;
}

add_action( 'manage_post_tag_custom_column', 'lexiterm_render_column', 10, 3 );
add_action( 'manage_category_custom_column', 'lexiterm_render_column', 10, 3 );
function lexiterm_render_column( $content, $column_name, $term_id ) {
	if ( 'lexiterm_action' !== $column_name ) {
		return $content;
	}

	$term = get_term( $term_id );
	if ( is_wp_error( $term ) ) {
		return $content;
	}

	$content = sprintf(
		'<button type="button" class="button button-small aitd-generate" data-term-id="%d" data-term-name="%s" data-taxonomy="%s">%s</button><span class="aitd-status"></span>',
		intval( $term_id ),
		esc_attr( $term->name ),
		esc_attr( $term->taxonomy ),
		esc_html__( 'Generate AI & Save', 'lexiterm' )
	);

	return $content;
}

/* ─────────────────────────────────────────────
 * 4. ENQUEUE ADMIN ASSETS
 * ───────────────────────────────────────────── */
add_action( 'admin_enqueue_scripts', 'lexiterm_enqueue_admin_assets' );
function lexiterm_enqueue_admin_assets( $hook ) {
	$allowed_screens = array( 'edit-post_tag', 'edit-category', 'term' );
	$screen          = get_current_screen();

	$is_settings  = ( 'settings_page_lexiterm' === $hook );
	$is_term_page = ( $screen && in_array( $screen->id, $allowed_screens, true ) );

	if ( ! $is_settings && ! $is_term_page ) {
		return;
	}

	/* CSS */
	wp_enqueue_style(
		'aitd-admin-css',
		LEXITERM_PLUGIN_URL . 'assets/css/admin.css',
		array(),
		LEXITERM_VERSION
	);

	/* JS — only on term pages */
	if ( $is_term_page ) {
		wp_enqueue_script(
			'aitd-admin-js',
			LEXITERM_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			LEXITERM_VERSION,
			true
		);

		wp_localize_script( 'aitd-admin-js', 'lexitermData', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'lexiterm_nonce' ),
			'i18n'    => array(
				'generating'    => __( 'Generating…', 'lexiterm' ),
				'waitMessage'   => __( 'AI is thinking, please wait…', 'lexiterm' ),
				'saved'         => __( '✓ Saved!', 'lexiterm' ),
				'regenerate'    => __( 'Regenerate', 'lexiterm' ),
				'errorRetry'    => __( 'Error! Retry', 'lexiterm' ),
				'errorPrefix'   => __( 'Error: ', 'lexiterm' ),
				'fillWithAI'    => __( 'Fill with AI', 'lexiterm' ),
				'aiThinking'    => __( 'AI is thinking…', 'lexiterm' ),
				'enterName'     => __( 'Please enter a name in the "Name" field first.', 'lexiterm' ),
				'generateSave'  => __( 'Generate AI & Save', 'lexiterm' ),
			),
		) );
	}
}

/* ─────────────────────────────────────────────
 * 5. AJAX HANDLER — GENERATE DESCRIPTION
 * ───────────────────────────────────────────── */
add_action( 'wp_ajax_lexiterm_generate', 'lexiterm_ajax_generate' );
function lexiterm_ajax_generate() {
	/* Security checks */
	check_ajax_referer( 'lexiterm_nonce', 'nonce' );

	if ( ! current_user_can( 'manage_categories' ) ) {
		wp_send_json_error( __( 'You do not have permission to perform this action.', 'lexiterm' ) );
	}

	$term_name = isset( $_POST['term_name'] ) ? sanitize_text_field( wp_unslash( $_POST['term_name'] ) ) : '';
	$term_id   = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;
	$taxonomy  = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : 'post_tag';
	$auto_save = isset( $_POST['auto_save'] ) ? absint( $_POST['auto_save'] ) : 0;

	if ( empty( $term_name ) ) {
		wp_send_json_error( __( 'Term name not found.', 'lexiterm' ) );
	}

	/* Get settings */
	$api_key = get_option( 'lexiterm_api_key', '' );
	if ( empty( $api_key ) ) {
		wp_send_json_error(
			__( 'Please enter your API key in Settings > AI Description.', 'lexiterm' )
		);
	}

	$model = get_option( 'lexiterm_model', 'gpt-3.5-turbo' );

	$default_prompt = __(
		"You are an experienced, SEO-expert content editor. Write a concise, natural, human-written description for the '{name}' category/tag on my website.\n\nRULES:\n1. Maximum 2-3 sentences.\n2. Do NOT use AI clichés (e.g., 'Welcome', 'Are you ready?'). Focus directly on action and content.\n3. Sentences should not repeat each other; avoid sounding mechanical.\n4. Naturally embed keywords like '{name}', 'free', 'online', 'best' into the text without forcing them.\n5. Use an energetic yet genuine tone that both informs and engages the visitor.",
		'lexiterm'
	);

	$raw_prompt = get_option( 'lexiterm_prompt', $default_prompt );
	if ( empty( $raw_prompt ) ) {
		wp_send_json_error(
			__( 'Prompt is empty. Please set a prompt in Settings > AI Description.', 'lexiterm' )
		);
	}

	/* Replace {name} placeholder */
	$prompt = str_replace( '{name}', $term_name, $raw_prompt );

	/* Call OpenAI API */
	$response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
		'headers' => array(
			'Authorization' => 'Bearer ' . $api_key,
			'Content-Type'  => 'application/json',
		),
		'body'    => wp_json_encode( array(
			'model'             => $model,
			'messages'          => array(
				array( 'role' => 'user', 'content' => $prompt ),
			),
			'max_tokens'        => 200,
			'temperature'       => 0.85,
			'frequency_penalty' => 0.4,
			'presence_penalty'  => 0.3,
		) ),
		'timeout' => 30,
	) );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error(
			/* translators: %s: error message from API */
			sprintf( __( 'API connection error: %s', 'lexiterm' ), $response->get_error_message() )
		);
	}

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( isset( $data['choices'][0]['message']['content'] ) ) {
		$ai_text = sanitize_textarea_field( trim( $data['choices'][0]['message']['content'] ) );

		/* Auto-save to term if requested */
		if ( 1 === $auto_save && $term_id > 0 && ! empty( $taxonomy ) ) {
			$update = wp_update_term( $term_id, $taxonomy, array(
				'description' => $ai_text,
			) );

			if ( is_wp_error( $update ) ) {
				wp_send_json_error(
					__( 'Description was generated but could not be saved to the database.', 'lexiterm' )
				);
			}
		}

		wp_send_json_success( $ai_text );
	} else {
		$error_msg = isset( $data['error']['message'] )
			? $data['error']['message']
			: __( 'The AI could not respond. Your API balance may be exhausted.', 'lexiterm' );

		wp_send_json_error( $error_msg );
	}
}