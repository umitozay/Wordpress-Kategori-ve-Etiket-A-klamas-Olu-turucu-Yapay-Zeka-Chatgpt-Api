﻿/**
 * LexiTerm â€” Admin JavaScript
 *
 * @package AI_Term_Description
 * @since   1.0.0
 */

(function ($) {
    'use strict';

    if (typeof lexitermData === 'undefined') {
        return;
    }

    var i18n = lexitermData.i18n;

    $(document).ready(function () {

        /* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
         * 1. LEFT-SIDE FORM (Add New / Edit Term)
         * â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        var descriptionTextarea = $(
            'textarea#tag-description, textarea#description, textarea#category-description'
        );
        var currentTaxonomy =
            $('input[name="taxonomy"]').val() || 'post_tag';

        if (descriptionTextarea.length > 0) {
            var buttonHtml =
                '<div class="aitd-form-button-wrap">' +
                '<button type="button" id="aitd-form-generate" class="button button-primary">' +
                i18n.fillWithAI +
                '</button>' +
                '<span id="aitd-form-loading" class="aitd-loading-text" style="display:none;">' +
                '<em>' + i18n.aiThinking + '</em>' +
                '</span>' +
                '</div>';

            descriptionTextarea.after(buttonHtml);
        }

        $('#aitd-form-generate').on('click', function (e) {
            e.preventDefault();

            var termName = $('#name').length
                ? $('#name').val()
                : $('#tag-name').val();

            if (!termName || termName.trim() === '') {
                alert(i18n.enterName);
                return;
            }

            var $btn = $(this);
            var $loading = $('#aitd-form-loading');

            $loading.show();
            $btn.prop('disabled', true);

            $.ajax({
                url: lexitermData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'lexiterm_generate',
                    term_name: termName,
                    taxonomy: currentTaxonomy,
                    auto_save: 0,
                    nonce: lexitermData.nonce,
                },
                success: function (response) {
                    $loading.hide();
                    $btn.prop('disabled', false);

                    if (response.success) {
                        descriptionTextarea.val(response.data);
                    } else {
                        alert(i18n.errorPrefix + response.data);
                    }
                },
                error: function () {
                    $loading.hide();
                    $btn.prop('disabled', false);
                },
            });
        });

        /* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
         * 2. TABLE INLINE GENERATE & SAVE BUTTONS
         * â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        $('.aitd-generate').on('click', function (e) {
            e.preventDefault();

            var $btn = $(this);
            var termId = $btn.data('term-id');
            var termName = $btn.data('term-name');
            var taxonomy = $btn.data('taxonomy');
            var $status = $btn.siblings('.aitd-status');
            var $descColumn = $btn.closest('tr').find('.column-description');

            $btn.prop('disabled', true).text(i18n.generating);
            $status.css('color', '#555').text(i18n.waitMessage);

            $.ajax({
                url: lexitermData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'lexiterm_generate',
                    term_name: termName,
                    term_id: termId,
                    taxonomy: taxonomy,
                    auto_save: 1,
                    nonce: lexitermData.nonce,
                },
                success: function (response) {
                    if (response.success) {
                        $btn.text(i18n.regenerate).prop('disabled', false);
                        $status.css('color', '#46b450').text(i18n.saved);
                        $descColumn.text(response.data);
                    } else {
                        $btn.text(i18n.errorRetry).prop('disabled', false);
                        $status.css('color', '#dc3232').text(
                            i18n.errorPrefix + response.data
                        );
                    }
                },
                error: function () {
                    $btn.text(i18n.errorRetry).prop('disabled', false);
                    $status.css('color', '#dc3232').text(
                        i18n.errorPrefix + 'Network error.'
                    );
                },
            });
        });
    });
})(jQuery);
