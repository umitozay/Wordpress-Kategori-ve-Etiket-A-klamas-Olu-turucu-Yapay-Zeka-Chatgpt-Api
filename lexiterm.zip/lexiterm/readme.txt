=== LexiTerm ===
Contributors: umitozay
Tags: seo, openai, chatgpt, category description, tag description
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate SEO-friendly, human-like descriptions for your WordPress categories and tags using OpenAI (ChatGPT) with a single click.

== Description ==

Creating unique, SEO-optimized descriptions for every category and tag on your website is a tedious and time-consuming task. **LexiTerm** solves this by integrating OpenAI's powerful language models directly into your WordPress term management screens.

With just **one click**, you can generate natural, human-like, and semantically rich descriptions for all your categories and tags — right from the WordPress dashboard!

= ✨ Key Features =

* **1-Click Generation & Save** — Generate and instantly save AI descriptions from the Categories or Tags list view, without page reloads.
* **Multiple AI Models** — Choose from GPT-3.5 Turbo, GPT-4, GPT-4o, GPT-4o Mini, and GPT-4 Turbo.
* **Customizable Prompts** — Write your own AI prompt in any language. Use `{name}` as a placeholder for the term name.
* **Settings Panel** — Easy-to-use settings page under Settings > AI Description.
* **Auto-Save via AJAX** — Descriptions are saved to your database instantly.
* **Add/Edit Term Support** — "Fill with AI" button on the Add New and Edit term screens.
* **Translation Ready** — Fully internationalized with 30+ language translations included.
* **SEO Plugin Compatible** — Works perfectly with Yoast SEO, Rank Math, All in One SEO, and any plugin that reads native WordPress term descriptions.
* **Lightweight & Fast** — No bloat. Only loads assets on relevant admin pages.
* **Clean Uninstall** — Removes all plugin data from your database when you uninstall.

= 🌍 Included Languages =

Arabic, Chinese (Simplified), Chinese (Traditional), Czech, Danish, Dutch, English, Finnish, French, German, Greek, Hebrew, Hindi, Hungarian, Indonesian, Italian, Japanese, Korean, Malay, Norwegian, Polish, Portuguese (Brazil), Portuguese (Portugal), Romanian, Russian, Spanish, Swedish, Thai, Turkish, Ukrainian, Vietnamese.

= 🔑 How It Works =

1. Enter your OpenAI API key in the settings.
2. Choose your preferred AI model.
3. Customize the prompt template (or use the excellent default).
4. Go to Categories or Tags and click "Generate AI & Save" — done!

= Requirements =

* An OpenAI API key (get one at [platform.openai.com](https://platform.openai.com/api-keys))
* WordPress 5.8 or later
* PHP 7.4 or later

== Installation ==

1. Upload the `lexiterm` folder to `/wp-content/plugins/`, or install directly from the WordPress plugin repository.
2. Activate the plugin through **Plugins** in WordPress.
3. Go to **Settings > AI Description**.
4. Enter your OpenAI API key.
5. (Optional) Select a model and customize the prompt.
6. Navigate to **Posts > Categories** or **Posts > Tags** and click **"Generate AI & Save"** next to any term!

== Frequently Asked Questions ==

= Is this plugin free? =
Yes! The plugin is 100% free and open-source (GPLv2+). However, generating AI content requires an OpenAI API key, which operates on OpenAI's usage-based pricing.

= Can I use it in my language? =
Absolutely! The plugin interface is translated into 30+ languages. Additionally, you can write your prompt in any language — the AI will respond in whatever language you specify.

= Does it overwrite existing descriptions? =
Yes. Clicking "Generate AI & Save" on a term with an existing description will replace it with the new AI-generated content.

= Which AI model should I choose? =
* **GPT-3.5 Turbo** — Fastest and most affordable. Great for most use cases.
* **GPT-4o Mini** — Good balance of quality and cost.
* **GPT-4o** — High quality, fast.
* **GPT-4 / GPT-4 Turbo** — Highest quality for complex prompts.

= Is my API key safe? =
Your API key is stored in your WordPress database and is only sent directly to OpenAI's servers. It is never shared with any third party.

== Screenshots ==

1. Settings panel — Enter API key, select model, and customize the prompt.
2. Categories list — "Generate AI & Save" button for each category.
3. Tags list — Inline AI generation with instant save.
4. Add/Edit term — "Fill with AI" button on the term editor.

== External Services ==

This plugin uses the OpenAI API to generate text descriptions for categories and tags. 

* **Service:** OpenAI API (https://api.openai.com)
* **Data Sent:** The name of the category or tag and the custom prompt provided in settings. No personal user data is transmitted.
* **Purpose:** To generate SEO-friendly descriptions using AI.
* **Terms of Service:** https://openai.com/policies/terms-of-use
* **Privacy Policy:** https://openai.com/policies/privacy-policy

== Changelog ==

= 1.0.0 =
* Initial release.
* One-click AI description generation for categories and tags.
* Support for multiple OpenAI models (GPT-3.5, GPT-4, GPT-4o, GPT-4o Mini, GPT-4 Turbo).
* Customizable prompt templates with `{name}` variable.
* Full internationalization with 30+ language translations.
* AJAX-powered inline generation and save.
* Clean uninstall support.

== Upgrade Notice ==

= 1.0.0 =
Initial release. Install and start generating AI descriptions for your terms!