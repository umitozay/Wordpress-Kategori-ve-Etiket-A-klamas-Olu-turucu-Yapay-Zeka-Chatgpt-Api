<?php
/**
 * Uninstall handler — removes all plugin options.
 *
 * @package AI_Term_Description
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'lexiterm_api_key' );
delete_option( 'lexiterm_model' );
delete_option( 'lexiterm_prompt' );
